module Proof.Matcher.Ord where

import Proof.Matcher.Core

toBeLessThan :: Ord a => Matcher a a
toBeLessThan = ("", (<))

toBeLessThanOrEqualTo :: Ord a => Matcher a a
toBeLessThanOrEqualTo = ("", (<=))

toBeGreaterThanOrEqualTo :: Ord a => Matcher a a
toBeGreaterThanOrEqualTo = ("", (>=))

toBeGreaterThan :: Ord a => Matcher a a
toBeGreaterThan = ("", (>))
