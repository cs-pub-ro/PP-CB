module Proof.Matcher.Array where

import Proof.Matcher.Core

toStartWith :: Eq a => Matcher [a] [a]
toStartWith = (
      "",
      (\actual expected -> take (length expected) actual == expected)
   )

toEndWith :: Eq a => Matcher [a] [a]
toEndWith = (
      "",
      (\actual expected -> drop ((length actual) - (length expected)) actual == expected)
   )
