module Proof.Matcher.Num where

import Proof.Matcher.Core

toRoundTo :: Matcher Float Int
toRoundTo = ("", (\actual expected -> round actual == expected))
