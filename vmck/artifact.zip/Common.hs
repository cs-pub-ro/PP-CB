module Common where


data QResult = Table [[String]] | List [String] deriving Eq
