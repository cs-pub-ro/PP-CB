module Proof.Matcher.Array where

import Proof.Matcher.Core

toStartWith :: Eq a => Matcher [a] [a]
toStartWith = (
      "Wrong result!",
      (\actual expected -> take (length expected) actual == expected)
   )

toEndWith :: Eq a => Matcher [a] [a]
toEndWith = (
    "Wrong result!",
      (\actual expected -> drop ((length actual) - (length expected)) actual == expected)
   )
