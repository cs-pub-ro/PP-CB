module Proof.Matcher.Ord where

import Proof.Matcher.Core

toBeLessThan :: Ord a => Matcher a a
toBeLessThan = ("Wrong result!", (<))

toBeLessThanOrEqualTo :: Ord a => Matcher a a
toBeLessThanOrEqualTo = ("Wrong result!", (<=))

toBeGreaterThanOrEqualTo :: Ord a => Matcher a a
toBeGreaterThanOrEqualTo = ("Wrong result!", (>=))

toBeGreaterThan :: Ord a => Matcher a a
toBeGreaterThan = ("Wrong result!", (>))
