module Proof.Matcher.Num where

import Proof.Matcher.Core

toRoundTo :: Matcher Float Int
toRoundTo = ("Wrong result!", (\actual expected -> round actual == expected))
