module Proof.Matcher.Core where

import Data.List

type FailMessage = String
type Evaluator actual expected = actual -> expected -> Bool
type Matcher actual expected = (FailMessage, Evaluator actual expected)

toBe :: Eq a => Matcher a a
toBe = ("Wrong result!", (==))

toBeF :: Matcher Float Float
toBeF = ("Wrong result!", (\x y -> (abs (x - y)) < 0.01))

toNotBe :: Eq a => Matcher a a
toNotBe = ("Wrong result!", (/=))


toBeSorted :: Ord a => Matcher [a] [a]
toBeSorted = ("Wrong result!", 
   \left right -> ((sortBy compare left) == (sortBy compare right)))
