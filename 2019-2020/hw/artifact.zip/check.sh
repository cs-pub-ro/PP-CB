make run_test
