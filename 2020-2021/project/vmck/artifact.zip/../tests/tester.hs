module Test where

import Main

values_stage1 = dict [
    ("s1_t1", 15),
    ("s1_t2_1", 5),
    ("s1_t2_2", 5),
    ("s1_t2_3", 5),
    ("s1_t2_4", 5),
    ("s1_t3", 15),
    ("s1_t4", 15),
    ("s1_t5", 20),
    ("s1_t6", 15)
    ]

stages_values = dict [
    ("s1", 10),
    ("s2", 10),
    ("s3", 10),
    ("s4", 10)
    ]

main = putStrLn "Hello!"
